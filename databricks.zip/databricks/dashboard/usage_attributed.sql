-- Attributed usage: one row per day x product x project area x basis x asset.
-- First matching rule wins:
--   6 platform   : projectarea=platform tag, untaggable product, platform warehouse, or the finops schema
--   5 allocated  : area warehouse, in an hour where a query's data or folder belongs to another area (split by task time)
--   9 corrected  : tag disagrees with the notebook folder or the job's folder; the folder wins
--   1 measured   : projectarea tag on the usage row
--   2 inferred   : notebook path under /ProjectAreas/<pa>/
--   3 inferred   : job mapped to an area by the reconciliation job, or the job's own tag
--   4 inferred   : Unity Catalog schema of a project area (predictive optimization, monitoring)
--   7 inferred   : the person's primary area, or the area of the group they ran as
--   8 unattributed: no signal. Reported, never spread.
-- Sandbox reads system.*; in the real environment swap to sbx_mr_bdap_system / prd_mr_bdap_system.
WITH prices AS (
  SELECT sku_name, cloud, price_start_time, price_end_time, pricing.effective_list.default AS unit_price
  FROM system.billing.list_prices
),
dim AS (SELECT * FROM projectareas.finops.dim_project_area),
jobs AS (
  SELECT workspace_id, job_id, name AS job_name, tags['projectarea'] AS job_pa
  FROM system.lakeflow.jobs
  QUALIFY ROW_NUMBER() OVER (PARTITION BY workspace_id, job_id ORDER BY change_time DESC) = 1
),
clusters AS (
  SELECT workspace_id, cluster_id, cluster_name
  FROM system.compute.clusters
  QUALIFY ROW_NUMBER() OVER (PARTITION BY workspace_id, cluster_id ORDER BY change_time DESC) = 1
),
job_map AS (
  SELECT m.job_id, m.pa_code FROM projectareas.finops.job_pa_map m JOIN dim d ON m.pa_code = d.pa_code
),
members AS (
  SELECT user_email, COUNT(DISTINCT pa_code) AS areas FROM projectareas.finops.user_area_membership GROUP BY user_email
),
primary_pa AS (
  SELECT user_email, pa_code FROM projectareas.finops.user_primary_pa WHERE valid_to IS NULL
),
q AS (
  SELECT warehouse_id, date_trunc('HOUR', start_time) AS hr, status,
         coalesce(CASE WHEN status = 'mismatch' THEN signal_area END, warehouse_area) AS area,
         greatest(coalesce(task_ms, 0), 1) AS ms
  FROM projectareas.finops.query_pa_map
),
mismatch_hours AS (
  SELECT warehouse_id, hr FROM q GROUP BY warehouse_id, hr HAVING COUNT_IF(status = 'mismatch') > 0
),
query_shares AS (
  SELECT q.warehouse_id, q.hr, q.area,
         SUM(q.ms) / SUM(SUM(q.ms)) OVER (PARTITION BY q.warehouse_id, q.hr) AS share
  FROM q JOIN mismatch_hours h ON q.warehouse_id = h.warehouse_id AND q.hr = h.hr
  GROUP BY q.warehouse_id, q.hr, q.area
),
u AS (
  SELECT
    x.usage_date, x.workspace_id, x.billing_origin_product AS product, x.sku_name,
    x.usage_quantity * coalesce(s.share, 1.0) AS dbus,
    x.usage_quantity * coalesce(s.share, 1.0) * p.unit_price AS list_cost,
    x.custom_tags['projectarea'] AS tag_pa,
    s.area AS query_pa,
    NULLIF(regexp_extract(x.usage_metadata.notebook_path, '^/(?:Workspace/)?ProjectAreas/([^/]+)/', 1), '') AS folder_pa,
    jm.pa_code AS mapped_job_pa,
    j.job_pa,
    pw.pa_code AS platform_wh,
    CASE WHEN x.usage_metadata.uc_table_catalog = 'projectareas' THEN sd.pa_code END AS schema_pa,
    x.usage_metadata.uc_table_catalog = 'projectareas' AND x.usage_metadata.uc_table_schema = 'finops' AS is_finops,
    coalesce(x.identity_metadata.run_as, x.identity_metadata.owned_by, '(none)') AS run_as,
    coalesce(pp.pa_code, NULLIF(regexp_extract(x.identity_metadata.run_as, '^pa-(.+)-(?:contributor|reader)$', 1), '')) AS primary_area,
    coalesce(mb.areas, 0) > 1 AS is_multi_area,
    CASE WHEN x.usage_metadata.job_id IS NOT NULL THEN 'job'
         WHEN x.usage_metadata.notebook_path IS NOT NULL THEN 'notebook'
         WHEN x.usage_metadata.warehouse_id IS NOT NULL THEN 'warehouse'
         WHEN x.usage_metadata.cluster_id IS NOT NULL THEN 'cluster'
         WHEN x.usage_metadata.dlt_pipeline_id IS NOT NULL THEN 'pipeline'
         WHEN x.usage_metadata.endpoint_name IS NOT NULL THEN 'endpoint'
         WHEN x.usage_metadata.app_name IS NOT NULL THEN 'app'
         ELSE lower(x.billing_origin_product) END AS asset_type,
    coalesce(x.usage_metadata.job_id, x.usage_metadata.notebook_path, x.usage_metadata.warehouse_id, x.usage_metadata.cluster_id,
             x.usage_metadata.dlt_pipeline_id, x.usage_metadata.endpoint_name, x.usage_metadata.app_name, '-') AS asset_id,
    coalesce(j.job_name, x.usage_metadata.job_name, c.cluster_name, x.usage_metadata.notebook_path, x.usage_metadata.warehouse_id,
             x.usage_metadata.cluster_id, x.usage_metadata.dlt_pipeline_id, x.usage_metadata.endpoint_name, x.usage_metadata.app_name, '-') AS asset_name
  FROM system.billing.usage x
  LEFT JOIN prices p
    ON x.sku_name = p.sku_name AND x.cloud = p.cloud
   AND x.usage_start_time >= p.price_start_time
   AND (p.price_end_time IS NULL OR x.usage_start_time < p.price_end_time)
  LEFT JOIN jobs j ON x.workspace_id = j.workspace_id AND x.usage_metadata.job_id = j.job_id
  LEFT JOIN clusters c ON x.workspace_id = c.workspace_id AND x.usage_metadata.cluster_id = c.cluster_id
  LEFT JOIN job_map jm ON x.usage_metadata.job_id = jm.job_id
  LEFT JOIN dim sd ON x.usage_metadata.uc_table_schema = sd.`schema`
  LEFT JOIN dim pw ON x.usage_metadata.warehouse_id = pw.sql_warehouse_id AND pw.pa_code = 'platform'
  LEFT JOIN members mb ON x.identity_metadata.run_as = mb.user_email
  LEFT JOIN primary_pa pp ON x.identity_metadata.run_as = pp.user_email
  LEFT JOIN query_shares s ON x.usage_metadata.warehouse_id = s.warehouse_id AND date_trunc('HOUR', x.usage_start_time) = s.hr
  WHERE x.usage_date >= current_date() - INTERVAL 180 DAYS
),
a AS (
  SELECT *,
    tag_pa IS NOT NULL AND tag_pa NOT IN ('unassigned', 'platform') AS has_area_tag
  FROM u
),
r AS (
  SELECT *,
    CASE WHEN tag_pa = 'platform' OR product = 'NETWORKING' OR platform_wh IS NOT NULL OR is_finops THEN 6
         WHEN has_area_tag AND query_pa IS NOT NULL AND query_pa <> tag_pa THEN 5
         WHEN has_area_tag AND folder_pa IS NOT NULL AND folder_pa <> tag_pa THEN 9
         WHEN has_area_tag AND mapped_job_pa IS NOT NULL AND mapped_job_pa <> tag_pa THEN 9
         WHEN has_area_tag THEN 1
         WHEN folder_pa IS NOT NULL THEN 2
         WHEN mapped_job_pa IS NOT NULL THEN 3
         WHEN job_pa IS NOT NULL AND job_pa NOT IN ('unassigned', 'platform') THEN 3
         WHEN schema_pa IS NOT NULL THEN 4
         WHEN primary_area IS NOT NULL THEN 7
         ELSE 8 END AS rule_id
  FROM a
)
SELECT
  usage_date,
  CAST(date_trunc('MONTH', usage_date) AS DATE) AS usage_month,
  workspace_id, product, sku_name, rule_id, is_multi_area,
  CASE product
    WHEN 'JOBS'               THEN 'Jobs'
    WHEN 'SQL'                THEN 'SQL warehouse'
    WHEN 'INTERACTIVE'        THEN 'Serverless notebook'
    WHEN 'ALL_PURPOSE'        THEN 'All-purpose cluster'
    WHEN 'DLT'                THEN 'Pipelines'
    WHEN 'GENIE'              THEN 'Genie'
    WHEN 'MODEL_SERVING'      THEN 'Model serving'
    WHEN 'VECTOR_SEARCH'      THEN 'Vector search'
    WHEN 'APPS'               THEN 'Apps'
    WHEN 'DATABASE'           THEN 'Lakebase'
    WHEN 'NETWORKING'         THEN 'Networking'
    WHEN 'PREDICTIVE_OPTIMIZATION' THEN 'Predictive optimization'
    ELSE initcap(replace(product, '_', ' ')) END AS workload_type,
  CASE rule_id WHEN 1 THEN 'measured' WHEN 5 THEN 'allocated' WHEN 6 THEN 'platform' WHEN 8 THEN 'unattributed'
               WHEN 9 THEN 'corrected' ELSE 'inferred' END AS basis,
  CASE rule_id WHEN 1 THEN coalesce(query_pa, tag_pa) WHEN 5 THEN query_pa WHEN 6 THEN 'platform'
               WHEN 9 THEN coalesce(folder_pa, mapped_job_pa)
               WHEN 2 THEN folder_pa WHEN 3 THEN coalesce(mapped_job_pa, job_pa) WHEN 4 THEN schema_pa WHEN 7 THEN primary_area
               ELSE coalesce(nullif(tag_pa, ''), 'unattributed') END AS projectarea,
  run_as, asset_type, asset_id, asset_name,
  CASE WHEN rule_id <> 1 THEN coalesce(folder_pa, mapped_job_pa, job_pa, schema_pa, primary_area) END AS suggested_pa,
  SUM(dbus) AS dbus,
  SUM(coalesce(list_cost, 0)) AS list_cost
FROM r
GROUP BY ALL
