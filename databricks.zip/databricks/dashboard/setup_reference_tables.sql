-- Reference tables for project-area attribution (PoC design, Appendix C). Safe to re-run.
CREATE SCHEMA IF NOT EXISTS projectareas.finops COMMENT 'FinOps reference and log tables for project-area cross-charging';

CREATE OR REPLACE TABLE projectareas.finops.dim_project_area (
  pa_code STRING NOT NULL, name STRING, tag_value STRING,
  folder_prefix STRING, catalog STRING, `schema` STRING,
  serverless_policy_id STRING, sql_warehouse_id STRING
);

INSERT INTO projectareas.finops.dim_project_area VALUES
  ('projecta', 'Project A', 'projecta', '/ProjectAreas/projecta/', 'projectareas', 'projecta', 'facb6626-4e01-44aa-b072-6d4060079f15', 'abf329d79556dde2'),
  ('projectb', 'Project B', 'projectb', '/ProjectAreas/projectb/', 'projectareas', 'projectb', 'ea54350a-ec36-4970-a606-cd3b58a4d973', '5f67a56419c45dfa'),
  ('platform', 'Platform',  'platform', NULL, NULL, NULL, NULL, '7b58ad3b7d0ff907');

-- Multi-area users are left for area owners to nominate; the reconciliation job fills in single-area users.
CREATE TABLE IF NOT EXISTS projectareas.finops.user_primary_pa (
  user_email STRING NOT NULL, pa_code STRING NOT NULL, valid_from DATE, valid_to DATE
);

CREATE TABLE IF NOT EXISTS projectareas.finops.user_area_membership (user_email STRING, pa_code STRING);

CREATE TABLE IF NOT EXISTS projectareas.finops.query_pa_map (
  query_id STRING, warehouse_id STRING, warehouse_area STRING, user_name STRING, start_time TIMESTAMP,
  task_ms BIGINT, signal_area STRING, signal STRING, status STRING, last_checked TIMESTAMP
);
