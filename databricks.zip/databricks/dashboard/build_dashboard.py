"""Builds the 'Project Area Cost' AI/BI dashboard definition (project-area-cost.lvdash.json).

Usage:
  python build_dashboard.py              # write the .lvdash.json only
  python build_dashboard.py --deploy     # also test every dataset query, create/update and publish the dashboard
Deploy needs the Azure CLI logged in as a workspace admin (az login).
"""
import json, pathlib, sys

HERE = pathlib.Path(__file__).parent
DASHBOARD_NAME = "Project Area Cost"
PARENT_PATH = "/Users/user1@rackspacedevops.onmicrosoft.com"
WAREHOUSE_ID = "7b58ad3b7d0ff907"  # Serverless Starter Warehouse, admins only (platform cost)

USAGE_SQL = (HERE / "usage_attributed.sql").read_text(encoding="utf-8").strip()
USAGE_BODY = "\n".join(l for l in USAGE_SQL.splitlines() if not l.lstrip().startswith("--"))

DATASETS = {
    "usage": ("Attributed usage", USAGE_SQL),
    "kpi": ("Attribution KPIs", f"""WITH a AS (
{USAGE_BODY}
)
SELECT
  SUM(CASE WHEN basis IN ('measured', 'inferred', 'corrected', 'allocated') THEN dbus END) / SUM(dbus) AS pct_attributed,
  SUM(CASE WHEN basis = 'measured' THEN dbus END) / SUM(dbus) AS pct_measured,
  SUM(CASE WHEN basis = 'unattributed' THEN dbus END) / SUM(dbus) AS pct_unattributed,
  coalesce(SUM(CASE WHEN is_multi_area THEN dbus END), 0) / SUM(dbus) AS pct_multi_area,
  coalesce(SUM(CASE WHEN is_multi_area AND basis IN ('corrected', 'allocated') THEN dbus END)
           / SUM(CASE WHEN is_multi_area THEN dbus END), 0) AS pct_multi_area_wrong,
  SUM(coalesce(list_cost, 0)) AS list_cost,
  SUM(dbus) AS dbus
FROM a
WHERE usage_month = (SELECT MAX(usage_month) FROM a)"""),
    "recon": ("Reconciliation", f"""WITH a AS (
{USAGE_BODY}
),
src AS (
  SELECT SUM(usage_quantity) AS dbus, MAX(usage_end_time) AS as_of
  FROM system.billing.usage WHERE usage_date >= current_date() - INTERVAL 180 DAYS
)
SELECT CAST(src.as_of AS STRING) AS source_as_of,
       ROUND(src.dbus, 6) AS source_dbus,
       ROUND((SELECT SUM(dbus) FROM a), 6) AS attributed_dbus,
       ROUND((SELECT SUM(dbus) FROM a) - src.dbus, 6) AS difference_dbus,
       CASE WHEN ABS((SELECT SUM(dbus) FROM a) - src.dbus) < 1e-6 THEN 'OK' ELSE 'MISMATCH' END AS status
FROM src"""),
    "showback": ("Monthly showback", f"""WITH a AS (
{USAGE_BODY}
)
SELECT CAST(usage_month AS STRING) AS month, projectarea, basis, workload_type, product,
       ROUND(SUM(dbus), 3) AS dbus, ROUND(SUM(coalesce(list_cost, 0)), 2) AS list_cost
FROM a GROUP BY ALL ORDER BY month DESC, projectarea, basis, product"""),
    "untagged": ("Untagged assets", f"""WITH a AS (
{USAGE_BODY}
)
SELECT workload_type, asset_type, asset_name, run_as AS owner, product, basis, projectarea,
       coalesce(suggested_pa, '?') AS suggested_pa,
       ROUND(SUM(dbus), 3) AS dbus_30d, ROUND(SUM(coalesce(list_cost, 0)), 2) AS list_cost_30d,
       CAST(MAX(usage_date) AS STRING) AS last_seen
FROM a
WHERE basis <> 'measured' AND usage_date >= current_date() - INTERVAL 30 DAYS
GROUP BY ALL ORDER BY dbus_30d DESC"""),
    "query_checks": ("Warehouse query checks", """SELECT CAST(start_time AS STRING) AS started, user_name, warehouse_area,
       coalesce(signal_area, '-') AS data_area, signal, status, task_ms
FROM projectareas.finops.query_pa_map
WHERE status IN ('mismatch', 'ambiguous') AND start_time >= current_timestamp() - INTERVAL 30 DAYS
ORDER BY start_time DESC"""),
    "corrections": ("Usage policy corrections", """SELECT CAST(changed_at AS STRING) AS changed_at, job_name, creator,
       pa_code AS projectarea, change, coalesce(old_value, '(none)') AS old_value, new_value
FROM projectareas.finops.job_pa_changes
WHERE changed_at >= current_timestamp() - INTERVAL 30 DAYS AND change <> 'permission'
ORDER BY changed_at DESC"""),
}

PCT ={"type": "number-percent", "decimalPlaces": {"type": "max", "places": 1}}
CUR = {"type": "number-currency", "currencyCode": "USD", "abbreviation": "compact", "decimalPlaces": {"type": "max", "places": 2}}
NUM = {"type": "number-plain", "abbreviation": "compact", "decimalPlaces": {"type": "max", "places": 2}}


def f(name, expr=None):
    return {"name": name, "expression": expr or f"`{name}`"}


def frame(title, desc=None):
    fr = {"showTitle": True, "title": title}
    if desc:
        fr["showDescription"] = True
        fr["description"] = desc
    return fr


def q(dataset, fields, disaggregated=False, name="main_query"):
    return {"name": name, "query": {"datasetName": dataset, "fields": fields, "disaggregated": disaggregated}}


def place(widget, x, y, w, h):
    return {"widget": widget, "position": {"x": x, "y": y, "width": w, "height": h}}


def text(name, lines):
    return {"name": name, "multilineTextboxSpec": {"lines": lines}}


def counter(name, dataset, field, expr, title, fmt, desc=None, disaggregated=False):
    return {"name": name, "queries": [q(dataset, [f(field, expr)], disaggregated)],
            "spec": {"version": 2, "widgetType": "counter",
                     "encodings": {"value": {"fieldName": field, "displayName": title, "format": fmt}},
                     "frame": frame(title, desc)}}


def bar(name, dataset, x, x_expr, x_scale, y, y_expr, color, title, desc=None, y_fmt=None):
    fields = [f(x, x_expr), f(y, y_expr), f(color)]
    enc = {"x": {"fieldName": x, "scale": {"type": x_scale}, "displayName": x.replace("_", " ").replace("daily(usage date)", "Day")},
           "y": {"fieldName": y, "scale": {"type": "quantitative"}, "displayName": y.split("(")[-1].rstrip(")").replace("_", " ")},
           "color": {"fieldName": color, "scale": {"type": "categorical"}, "displayName": color.replace("_", " ")}}
    if y_fmt:
        enc["y"]["format"] = y_fmt
    return {"name": name, "queries": [q(dataset, fields)],
            "spec": {"version": 3, "widgetType": "bar", "encodings": enc, "frame": frame(title, desc)}}


def table(name, dataset, cols, title, desc=None):
    columns = []
    for i, (field, label, typ) in enumerate(cols):
        columns.append({"fieldName": field, "title": label, "displayName": label, "type": typ,
                        "displayAs": "number" if typ in ("float", "integer") else "string",
                        "visible": True, "order": i, "alignContent": "right" if typ in ("float", "integer") else "left"})
    return {"name": name, "queries": [q(dataset, [f(c[0]) for c in cols], disaggregated=True)],
            "spec": {"version": 1, "widgetType": "table", "encodings": {"columns": columns},
                     "invisibleColumns": [], "allowHTMLByDefault": False, "itemsPerPage": 25,
                     "condensed": True, "withRowNumber": False, "frame": frame(title, desc)}}


def multi_filter(name, field, title, datasets):
    queries, enc = [], []
    for ds in datasets:
        qn = f"{name}_{ds}"
        queries.append(q(ds, [f(field)], name=qn))
        enc.append({"fieldName": field, "displayName": title, "queryName": qn})
    return {"name": name, "queries": queries,
            "spec": {"version": 2, "widgetType": "filter-multi-select", "encodings": {"fields": enc}, "frame": frame(title)}}


def date_filter(name, field, title, datasets):
    queries, enc = [], []
    for ds in datasets:
        qn = f"{name}_{ds}"
        queries.append(q(ds, [f(field)], name=qn))
        enc.append({"fieldName": field, "displayName": title, "queryName": qn})
    return {"name": name, "queries": queries,
            "spec": {"version": 2, "widgetType": "filter-date-range-picker", "encodings": {"fields": enc}, "frame": frame(title)}}


overview = [
    place(text("title", [
        "# Project Area Cost",
        "DBU cost per project area at **list price**, attributed by the PoC precedence rules. "
        "**measured** = projectarea tag on the usage row · **inferred** = folder, job or schema · "
        "**corrected** = tag disagreed with the folder, folder wins · **allocated** = split by query time · "
        "**platform** = untaggable or platform-tagged · **unattributed** = no signal (chase it in *Untagged assets*)."]), 0, 0, 6, 2),
    place(date_filter("f_date", "usage_date", "Usage date", ["usage"]), 0, 2, 2, 1),
    place(multi_filter("f_pa", "projectarea", "Project area", ["usage"]), 2, 2, 2, 1),
    place(multi_filter("f_type", "workload_type", "Workload type", ["usage"]), 4, 2, 2, 1),
    place(counter("k_attr", "kpi", "pct_attributed", None, "Attributed share (this month)", PCT,
                  "measured + inferred DBUs / all DBUs. PoC target: at least 90%.", disaggregated=True), 0, 3, 2, 3),
    place(counter("k_meas", "kpi", "pct_measured", None, "Measured share (this month)", PCT,
                  "DBUs whose usage row carries a projectarea tag.", disaggregated=True), 2, 3, 2, 3),
    place(counter("k_unat", "kpi", "pct_unattributed", None, "Unattributed share (this month)", PCT,
                  "No signal at all. Reported, never spread.", disaggregated=True), 4, 3, 2, 3),
    place(counter("k_cost", "usage", "sum(list_cost)", "SUM(`list_cost`)", "List cost (selection)", CUR), 0, 6, 2, 3),
    place(counter("k_dbus", "usage", "sum(dbus)", "SUM(`dbus`)", "DBUs (selection)", NUM), 2, 6, 2, 3),
    place(counter("k_multi", "kpi", "pct_multi_area", None, "Spend by multi-area users", PCT,
                  "This month, share of all DBUs.", disaggregated=True), 4, 6, 1, 3),
    place(counter("k_wrong", "kpi", "pct_multi_area_wrong", None, "Their spend on the wrong area", PCT,
                  "Tag disagreed with the folder or data used.", disaggregated=True), 5, 6, 1, 3),
    place(bar("b_pa_basis", "usage", "projectarea", None, "categorical", "sum(list_cost)", "SUM(`list_cost`)", "basis",
              "Cost by project area and basis", "Every line carries how strong its evidence is.", CUR), 0, 9, 3, 6),
    place(bar("b_pa_type", "usage", "projectarea", None, "categorical", "sum(list_cost)", "SUM(`list_cost`)", "workload_type",
              "Cost by project area and workload type", "Jobs, SQL warehouses, notebooks, clusters, Genie ...", CUR), 3, 9, 3, 6),
    place(bar("b_trend", "usage", "daily(usage_date)", 'DATE_TRUNC("DAY", `usage_date`)', "temporal",
              "sum(dbus)", "SUM(`dbus`)", "projectarea", "Daily DBUs by project area"), 0, 15, 6, 6),
    place(table("t_recon", "recon", [("status", "Status", "string"), ("source_dbus", "Source DBUs", "float"),
                                     ("attributed_dbus", "Attributed DBUs", "float"), ("difference_dbus", "Difference", "float"),
                                     ("source_as_of", "Source data as of", "string")],
                "Reconciliation to system.billing.usage (180 days)",
                "Acceptance test: difference must be 0. A mismatch blocks the showback."), 0, 21, 6, 3),
]

showback = [
    place(text("sb_title", ["## Monthly showback and untagged assets",
                            "Showback is published on day 3 of each month; owners dispute within 7 days. "
                            "Untagged assets go to their owners weekly: tag the asset (or move it to the area's policy) "
                            "and its next run lands as *measured*."]), 0, 0, 6, 2),
    place(multi_filter("f_pa2", "projectarea", "Project area", ["showback", "untagged"]), 0, 2, 3, 1),
    place(multi_filter("f_type2", "workload_type", "Workload type", ["showback", "untagged"]), 3, 2, 3, 1),
    place(table("t_showback", "showback", [("month", "Month", "string"), ("projectarea", "Project area", "string"),
                                           ("basis", "Basis", "string"), ("workload_type", "Workload type", "string"),
                                           ("product", "Product", "string"),
                                           ("dbus", "DBUs", "float"), ("list_cost", "List cost (USD)", "float")],
                "Showback by month, project area, basis and product"), 0, 3, 6, 8),
    place(table("t_untagged", "untagged", [("workload_type", "Workload type", "string"), ("asset_name", "Asset", "string"),
                                           ("owner", "Owner / run as", "string"), ("product", "Product", "string"),
                                           ("basis", "Basis", "string"), ("projectarea", "Billed to", "string"),
                                           ("suggested_pa", "Suggested area", "string"), ("dbus_30d", "DBUs 30d", "float"),
                                           ("list_cost_30d", "Cost 30d (USD)", "float"), ("last_seen", "Last seen", "string")],
                "Assets without a projectarea tag (last 30 days)",
                "Weekly untagged-usage report. Owners have 7 days to tag or confirm."), 0, 11, 6, 8),
    place(table("t_corrections", "corrections", [("changed_at", "Changed at (UTC)", "string"), ("job_name", "Job", "string"),
                                                 ("creator", "Created by", "string"), ("projectarea", "Area (from folder)", "string"),
                                                 ("change", "What", "string"), ("old_value", "Was", "string"),
                                                 ("new_value", "Now", "string")],
                "Automatic usage-policy corrections (last 30 days)",
                "The reconciliation job sets each serverless job's policy from its notebook folder. "
                "Earlier runs are moved to the folder's area in this report, labelled corrected."), 0, 19, 6, 6),
    place(table("t_query_checks", "query_checks", [("started", "Started (UTC)", "string"), ("user_name", "User", "string"),
                                                   ("warehouse_area", "Warehouse area", "string"), ("data_area", "Data / folder area", "string"),
                                                   ("signal", "Signal", "string"), ("status", "Status", "string"),
                                                   ("task_ms", "Task ms", "integer")],
                "SQL queries run on another area's warehouse (last 30 days)",
                "Their share of that hour's warehouse cost is reported as allocated."), 0, 25, 6, 6),
]

dashboard = {
    "datasets": [{"name": k, "displayName": v[0], "queryLines": [l + "\n" for l in v[1].splitlines()]} for k, v in DATASETS.items()],
    "pages": [
        {"name": "overview", "displayName": "Overview", "pageType": "PAGE_TYPE_CANVAS", "layout": overview},
        {"name": "showback", "displayName": "Showback & untagged", "pageType": "PAGE_TYPE_CANVAS", "layout": showback},
    ],
}

out = HERE / "project-area-cost.lvdash.json"
out.write_text(json.dumps(dashboard, indent=2), encoding="utf-8")
print(f"wrote {out}")

if "--deploy" in sys.argv:
    sys.path.insert(0, str(pathlib.Path(sys.argv[sys.argv.index("--deploy") + 1]) if len(sys.argv) > sys.argv.index("--deploy") + 1 else HERE))
    import dbx  # helper with api() and sql()
    for k, (label, stmt) in DATASETS.items():
        cols, rows = dbx.sql(stmt)
        print(f"dataset {k:9} OK  {len(rows)} rows  cols={cols}")
    body = {"display_name": DASHBOARD_NAME, "warehouse_id": WAREHOUSE_ID, "parent_path": PARENT_PATH,
            "serialized_dashboard": json.dumps(dashboard)}
    import urllib.parse
    try:  # find the existing dashboard by its workspace path
        node = dbx.api("GET", "/api/2.0/workspace/get-status?path=" +
                       urllib.parse.quote(f"{PARENT_PATH}/{DASHBOARD_NAME}.lvdash.json"))
        existing = node.get("resource_id")
    except RuntimeError:
        existing = None
    if existing:
        did = existing
        dbx.api("PATCH", f"/api/2.0/lakeview/dashboards/{did}", {k: v for k, v in body.items() if k != "parent_path"})
        print(f"updated dashboard {did}")
    else:
        did = dbx.api("POST", "/api/2.0/lakeview/dashboards", body)["dashboard_id"]
        print(f"created dashboard {did}")
    dbx.api("POST", f"/api/2.0/lakeview/dashboards/{did}/published", {"warehouse_id": WAREHOUSE_ID, "embed_credentials": True})
    print(f"published: {dbx.H}/dashboardsv3/{did}/published")
