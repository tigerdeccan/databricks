<#
.SYNOPSIS
  Provisions Databricks project areas for cross-charging (PoC design: "one tagged compute set per project area").

.DESCRIPTION
  Idempotent: safe to re-run. Creates what is missing and corrects what drifted.

  Per run (once):
    - Governed tag policy  'projectarea'  (allowed values = project-area codes + platform + unassigned)
    - Unity Catalog catalog  <CatalogName>  (managed location under an existing external location)
    - Workspace folder root  <FolderRoot>

  Per user in -UsersCsv (one row per membership):
    - Entra ID user <UserName>@<UserDomain> (random password, must change at first sign-in; written only to -CredentialsPath)
    - Databricks account user linked to it, added to the matching pa-<code>-<role> group in Entra ID and in Databricks

  Per project area <code>:
    - Entra ID security groups   pa-<code>-contributor, pa-<code>-reader
    - Databricks account groups linked to them (externalId = Entra object id), assigned to the workspace
    - UC schema  <CatalogName>.<code>  tagged projectarea=<code>; contributor = read/write, reader = read
    - Workspace folder  <FolderRoot>/<code>; contributor = CAN_MANAGE (write), reader = CAN_READ
    - Serverless usage policy  pa-<code>  (tag projectarea=<code>), User role to both groups
    - Compute policies  pa-<code>-all-purpose / pa-<code>-jobs  (fixed tag projectarea=<code>), CAN_USE to contributor

  Prerequisites: PowerShell 7+, Azure CLI logged in ('az login') as an identity that is
  Entra ID group creator, Databricks account admin and workspace admin.

.EXAMPLE
  ./New-DatabricksProjectAreas.ps1 -ProjectAreas projecta,projectb

.EXAMPLE
  ./New-DatabricksProjectAreas.ps1 -ProjectAreas projecta,projectb,projectc -WhatIf
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [string]   $WorkspaceResourceId = '/subscriptions/95ca9f68-a725-4017-9277-ea2999895a39/resourceGroups/databricks/providers/Microsoft.Databricks/workspaces/mksfree',
    [string]   $AccountId           = '532b7b67-011f-453c-9a3a-a299588f732d',
    [ValidatePattern('^[a-z0-9][a-z0-9-]*$')]
    [string[]] $ProjectAreas        = @('projecta', 'projectb'),
    [string]   $CatalogName         = 'projectareas',
    # Managed storage for the catalog. The metastore has no root storage, so this must sit under an external location.
    [string]   $CatalogStorageRoot  = 'abfss://unity-catalog-storage@dbstorage6ke3lwfedfaum.dfs.core.windows.net/7405606702497059/projectareas',
    [string]   $FolderRoot          = '/ProjectAreas',
    [string]   $TagKey              = 'projectarea',
    # Creating notebooks in a folder needs CAN_MANAGE; use CAN_EDIT if contributors should only edit existing items.
    [ValidateSet('CAN_MANAGE', 'CAN_EDIT')]
    [string]   $ContributorFolderPermission = 'CAN_MANAGE',
    [string]   $SummaryPath         = (Join-Path $PSScriptRoot 'projectareas-provisioned.json'),
    # Users to create and add to groups. Columns: UserName, DisplayName, ProjectArea, Role (contributor|reader).
    # One row per membership; a multi-area user has one row per area. Pass '' to skip users.
    [string]   $UsersCsv            = (Join-Path $PSScriptRoot 'ProjectAreaUsers.csv'),
    # UPN suffix for new users; defaults to the tenant's default domain.
    [string]   $UserDomain,
    # Initial passwords of newly created users only (file is chmod 600). Distribute, then delete it.
    [string]   $CredentialsPath     = (Join-Path $PSScriptRoot 'new-user-credentials.csv'),
    # Workspace entitlements per role. Never 'allow-cluster-create': classic compute must come from the tagged policies.
    [string[]] $ContributorEntitlements = @('workspace-access', 'databricks-sql-access'),
    [string[]] $ReaderEntitlements      = @('workspace-access', 'databricks-sql-access'),
    # Only admins create compute: pa-* policies get no CAN_USE for groups, Personal Compute is set to DELEGATE
    # (workspace ACL decides; only admins hold it), and each area gets an admin-created shared cluster instead.
    [bool]     $AdminOnlyCompute    = $true,
    [string]   $ClusterNodeType     = 'Standard_D4ds_v5',
    # CAN_RESTART = attach + start a terminated cluster; CAN_ATTACH_TO = attach only (cannot start it).
    [ValidateSet('CAN_ATTACH_TO', 'CAN_RESTART')]
    [string]   $ClusterPermission   = 'CAN_RESTART'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ---------- helpers ----------
$DatabricksAppId = '2ff814a6-3304-4ab8-85cb-cd0e6f879c1d'   # Azure Databricks first-party app
$script:Token = $null
$script:Summary = [ordered]@{ created = @(); updated = @(); unchanged = @(); skipped = @() }

function Write-Step([string]$Message) { Write-Host "==> $Message" -ForegroundColor Cyan }
function Add-Result([ValidateSet('created', 'updated', 'unchanged')] $Kind, [string]$What) {
    $script:Summary[$Kind] += $What
    $color = @{ created = 'Green'; updated = 'Yellow'; unchanged = 'DarkGray' }[$Kind]
    Write-Host ("    [{0}] {1}" -f $Kind, $What) -ForegroundColor $color
}

function Get-DbxToken {
    $t = az account get-access-token --resource $DatabricksAppId --query accessToken -o tsv
    if (-not $t) { throw 'Could not get a Databricks token. Run az login.' }
    $script:Token = $t
}

function Invoke-Dbx {
    param(
        [Parameter(Mandatory)][string]$Method,
        [Parameter(Mandatory)][string]$Uri,
        $Body,
        [int[]]$AllowStatus = @(),
        [int]$Retries = 6
    )
    for ($i = 1; ; $i++) {
        $p = @{
            Method = $Method; Uri = $Uri; Headers = @{ Authorization = "Bearer $script:Token" }
            ContentType = 'application/json'; SkipHttpErrorCheck = $true; StatusCodeVariable = 'sc'
        }
        if ($null -ne $Body) { $p.Body = ($Body | ConvertTo-Json -Depth 20 -Compress) }
        $r = Invoke-RestMethod @p
        if ($sc -lt 400 -or $AllowStatus -contains $sc) { return [pscustomobject]@{ Status = $sc; Body = $r } }
        # New account groups can take a few seconds to become visible to UC / workspace APIs.
        $msg = ($r | ConvertTo-Json -Depth 5 -Compress)
        $transient = $sc -in 429, 500, 502, 503, 504 -or ($sc -in 400, 404 -and $msg -match 'does not exist|not found|PRINCIPAL_DOES_NOT_EXIST|Could not find principal')
        if ($transient -and $i -lt $Retries) { Start-Sleep -Seconds (5 * $i); continue }
        throw "$Method $Uri failed ($sc): $msg"
    }
}

# ---------- resolve workspace ----------
Write-Step 'Resolving workspace'
$ws = az resource show --ids $WorkspaceResourceId --query '{url:properties.workspaceUrl, id:properties.workspaceId}' -o json | ConvertFrom-Json
if (-not $ws) { throw "Workspace not found: $WorkspaceResourceId" }
$H = "https://$($ws.url)"
$A = 'https://accounts.azuredatabricks.net/api'
$WorkspaceId = $ws.id
Get-DbxToken
Write-Host "    $H (workspace id $WorkspaceId)"

# ---------- 1. Entra ID groups + Databricks account groups ----------
function Confirm-EntraGroup([string]$Name, [string]$Description) {
    $id = az ad group list --display-name $Name --query '[0].id' -o tsv
    if ($id) { Add-Result unchanged "Entra ID group $Name ($id)"; return $id }
    if (-not $PSCmdlet.ShouldProcess($Name, 'Create Entra ID group')) { return $null }
    $id = az ad group create --display-name $Name --mail-nickname $Name --description $Description --query id -o tsv
    Add-Result created "Entra ID group $Name ($id)"
    return $id
}

function Confirm-AccountGroup([string]$Name, [string]$EntraId) {
    $filter = [uri]::EscapeDataString("displayName eq `"$Name`"")
    $r = Invoke-Dbx GET "$A/2.0/accounts/$AccountId/scim/v2/Groups?filter=$filter"
    $existing = @($r.Body.PSObject.Properties['Resources'] ? $r.Body.Resources : @())
    if ($existing.Count -gt 0) {
        $g = $existing[0]; Add-Result unchanged "Databricks account group $Name ($($g.id))"
    } else {
        if (-not $PSCmdlet.ShouldProcess($Name, 'Create Databricks account group')) { return $null }
        $body = @{ schemas = @('urn:ietf:params:scim:schemas:core:2.0:Group'); displayName = $Name }
        if ($EntraId) { $body.externalId = $EntraId }
        $g = (Invoke-Dbx POST "$A/2.0/accounts/$AccountId/scim/v2/Groups" $body).Body
        Add-Result created "Databricks account group $Name ($($g.id), externalId $EntraId)"
    }
    # Assign to the workspace with the USER permission (PUT is idempotent).
    if ($PSCmdlet.ShouldProcess("$Name -> workspace $WorkspaceId", 'Assign group')) {
        Invoke-Dbx PUT "$A/2.0/accounts/$AccountId/workspaces/$WorkspaceId/permissionassignments/principals/$($g.id)" @{ permissions = @('USER') } | Out-Null
    }
    return $g.id
}

$groups = [ordered]@{}
foreach ($pa in $ProjectAreas) {
    Write-Step "Groups for project area '$pa'"
    foreach ($role in 'contributor', 'reader') {
        $name = "pa-$pa-$role"
        $desc = "Databricks project area '$pa' - $role (catalog $CatalogName.$pa, folder $FolderRoot/$pa)"
        $eid = Confirm-EntraGroup $name $desc
        $did = Confirm-AccountGroup $name $eid
        $groups["$pa/$role"] = [ordered]@{ name = $name; entraObjectId = $eid; databricksGroupId = $did }
    }
}

# ---------- 1a. Workspace entitlements on the groups (this workspace's 'users' group has none) ----------
Write-Step 'Workspace entitlements'
foreach ($key in $groups.Keys) {
    $g = $groups[$key]
    if (-not $g.databricksGroupId) { continue }
    $want = if ($key -like '*/contributor') { $ContributorEntitlements } else { $ReaderEntitlements }
    $wg = (Invoke-Dbx GET "$H/api/2.0/preview/scim/v2/Groups/$($g.databricksGroupId)").Body
    $have = @(($wg.PSObject.Properties['entitlements'] ? $wg.entitlements : @()) | ForEach-Object { $_.value })
    $missing = @($want | Where-Object { $_ -notin $have })
    if ($missing.Count -eq 0) { Add-Result unchanged "Entitlements on $($g.name): $($want -join ', ')"; continue }
    if (-not $PSCmdlet.ShouldProcess($g.name, "Add entitlements $($missing -join ',')")) { continue }
    Invoke-Dbx PATCH "$H/api/2.0/preview/scim/v2/Groups/$($g.databricksGroupId)" @{
        schemas    = @('urn:ietf:params:scim:api:messages:2.0:PatchOp')
        Operations = @(@{ op = 'add'; path = 'entitlements'; value = @($missing | ForEach-Object { @{ value = $_ } }) })
    } | Out-Null
    Add-Result created "Entitlements on $($g.name): $($missing -join ', ')"
}

# ---------- 1b. Users: Entra ID user + group membership, Databricks account user + group membership ----------
function New-TempPassword {
    $sets = 'ABCDEFGHJKLMNPQRSTUVWXYZ', 'abcdefghijkmnpqrstuvwxyz', '23456789', '!#%*+-=?@'
    $all = -join $sets
    $chars = @($sets | ForEach-Object { $_[[System.Security.Cryptography.RandomNumberGenerator]::GetInt32($_.Length)] })
    $chars += 1..16 | ForEach-Object { $all[[System.Security.Cryptography.RandomNumberGenerator]::GetInt32($all.Length)] }
    -join ($chars | Sort-Object { [System.Security.Cryptography.RandomNumberGenerator]::GetInt32([int]::MaxValue) })
}

function Confirm-EntraUser([string]$Upn, [string]$DisplayName, [string]$MailNickname) {
    $id = az ad user list --filter "userPrincipalName eq '$Upn'" --query '[0].id' -o tsv
    if ($id) { Add-Result unchanged "Entra ID user $Upn ($id)"; return $id }
    if (-not $PSCmdlet.ShouldProcess($Upn, 'Create Entra ID user')) { return $null }
    $pw = New-TempPassword
    $id = az ad user create --display-name $DisplayName --user-principal-name $Upn --mail-nickname $MailNickname `
            --password $pw --force-change-password-next-sign-in true --query id -o tsv
    if (-not $id) { throw "Failed to create Entra ID user $Upn" }
    $script:NewCredentials += [pscustomobject]@{ UserPrincipalName = $Upn; DisplayName = $DisplayName; InitialPassword = $pw }
    Add-Result created "Entra ID user $Upn ($id), must change password at first sign-in"
    return $id
}

function Confirm-EntraMembership([string]$GroupId, [string]$GroupName, [string]$UserId, [string]$Upn) {
    $isMember = az ad group member check --group $GroupId --member-id $UserId --query value -o tsv
    if ($isMember -eq 'true') { Add-Result unchanged "Entra ID $Upn in $GroupName"; return }
    if (-not $PSCmdlet.ShouldProcess("$Upn -> $GroupName", 'Add Entra ID group member')) { return }
    az ad group member add --group $GroupId --member-id $UserId | Out-Null
    Add-Result created "Entra ID $Upn in $GroupName"
}

function Confirm-AccountUser([string]$Upn, [string]$DisplayName, [string]$EntraId) {
    $filter = [uri]::EscapeDataString("userName eq `"$Upn`"")
    $r = (Invoke-Dbx GET "$A/2.0/accounts/$AccountId/scim/v2/Users?filter=$filter").Body
    $existing = @($r.PSObject.Properties['Resources'] ? $r.Resources : @())
    if ($existing.Count -gt 0) { Add-Result unchanged "Databricks account user $Upn ($($existing[0].id))"; return $existing[0].id }
    if (-not $PSCmdlet.ShouldProcess($Upn, 'Create Databricks account user')) { return $null }
    $body = @{ schemas = @('urn:ietf:params:scim:schemas:core:2.0:User'); userName = $Upn; displayName = $DisplayName; active = $true }
    if ($EntraId) { $body.externalId = $EntraId }
    $u = (Invoke-Dbx POST "$A/2.0/accounts/$AccountId/scim/v2/Users" $body).Body
    Add-Result created "Databricks account user $Upn ($($u.id))"
    return $u.id
}

function Confirm-AccountMembership([string]$GroupId, [string]$GroupName, [string]$UserId, [string]$Upn) {
    $g = (Invoke-Dbx GET "$A/2.0/accounts/$AccountId/scim/v2/Groups/$GroupId").Body
    $members = @(($g.PSObject.Properties['members'] ? $g.members : @()) | ForEach-Object { $_.value })
    if ($members -contains $UserId) { Add-Result unchanged "Databricks $Upn in $GroupName"; return }
    if (-not $PSCmdlet.ShouldProcess("$Upn -> $GroupName", 'Add Databricks group member')) { return }
    Invoke-Dbx PATCH "$A/2.0/accounts/$AccountId/scim/v2/Groups/$GroupId" @{
        schemas    = @('urn:ietf:params:scim:api:messages:2.0:PatchOp')
        Operations = @(@{ op = 'add'; path = 'members'; value = @(@{ value = $UserId }) })
    } | Out-Null
    Add-Result created "Databricks $Upn in $GroupName"
}

$script:NewCredentials = @()
$userIds = [ordered]@{}
if ($UsersCsv -and (Test-Path $UsersCsv)) {
    Write-Step "Users from $UsersCsv"
    if (-not $UserDomain) {
        $UserDomain = az rest --method get --url 'https://graph.microsoft.com/v1.0/domains' --query 'value[?isDefault].id | [0]' -o tsv
    }
    $rows = @(Import-Csv $UsersCsv)
    foreach ($row in $rows) {
        if ($row.ProjectArea -notin $ProjectAreas) { throw "Row for $($row.UserName): project area '$($row.ProjectArea)' is not in -ProjectAreas" }
        if ($row.Role -notin 'contributor', 'reader') { throw "Row for $($row.UserName): role must be contributor or reader" }
    }
    foreach ($userRows in ($rows | Group-Object UserName)) {
        $first = $userRows.Group[0]
        $upn = "$($first.UserName)@$UserDomain".ToLower()
        $eid = Confirm-EntraUser $upn $first.DisplayName $first.UserName
        $did = Confirm-AccountUser $upn $first.DisplayName $eid
        # Assign the user directly too: users reached only through a group must enter the workspace by assuming
        # the group's role, and then act as the group (e.g. jobs fail: "cannot be created with a group identity").
        if ($did -and $PSCmdlet.ShouldProcess("$upn -> workspace $WorkspaceId", 'Assign user')) {
            Invoke-Dbx PUT "$A/2.0/accounts/$AccountId/workspaces/$WorkspaceId/permissionassignments/principals/$did" @{ permissions = @('USER') } | Out-Null
            Add-Result updated "Workspace assignment USER -> $upn"
        }
        $userIds[$upn] = [ordered]@{ entraObjectId = $eid; databricksUserId = $did; memberships = @() }
        foreach ($row in $userRows.Group) {
            $g = $groups["$($row.ProjectArea)/$($row.Role)"]
            if ($eid -and $g.entraObjectId)     { Confirm-EntraMembership $g.entraObjectId $g.name $eid $upn }
            if ($did -and $g.databricksGroupId) { Confirm-AccountMembership $g.databricksGroupId $g.name $did $upn }
            $userIds[$upn].memberships += $g.name
        }
    }
    if ($script:NewCredentials.Count -gt 0) {
        $script:NewCredentials | Export-Csv -Path $CredentialsPath -NoTypeInformation -Append
        if (-not $IsWindows) { chmod 600 $CredentialsPath }
        Write-Warning "Initial passwords for $($script:NewCredentials.Count) new user(s) appended to $CredentialsPath. Distribute securely, then delete the file."
    }
} elseif ($UsersCsv) { Write-Warning "Users file not found, skipping users: $UsersCsv" }

# ---------- 2. Governed tag policy ----------
Write-Step "Governed tag policy '$TagKey'"
$allowed = @($ProjectAreas) + @('platform', 'unassigned') | Select-Object -Unique
$tagBody = @{ tag_key = $TagKey; description = 'Project area for cross-charging. Values come from dim_project_area.'; values = @($allowed | ForEach-Object { @{ name = $_ } }) }
$tp = Invoke-Dbx GET "$H/api/2.1/tag-policies/$TagKey" -AllowStatus 404
if ($tp.Status -eq 404) {
    if ($PSCmdlet.ShouldProcess($TagKey, 'Create tag policy')) {
        Invoke-Dbx POST "$H/api/2.1/tag-policies" $tagBody | Out-Null
        Add-Result created "Tag policy $TagKey = [$($allowed -join ', ')]"
    }
} else {
    $current = @($tp.Body.values | ForEach-Object { $_.name })
    $merged = @($current) + @($allowed) | Select-Object -Unique   # never drop values that may already be in use
    if (@(Compare-Object $current $merged).Count -eq 0) {
        Add-Result unchanged "Tag policy $TagKey = [$($current -join ', ')]"
    } elseif ($PSCmdlet.ShouldProcess($TagKey, 'Update tag policy values')) {
        $tagBody.values = @($merged | ForEach-Object { @{ name = $_ } })
        Invoke-Dbx PATCH "$H/api/2.1/tag-policies/$($TagKey)?update_mask=values,description" $tagBody | Out-Null
        Add-Result updated "Tag policy $TagKey = [$($merged -join ', ')]"
    }
}

# ---------- 3. Catalog ----------
Write-Step "Catalog '$CatalogName'"
$c = Invoke-Dbx GET "$H/api/2.1/unity-catalog/catalogs/$CatalogName" -AllowStatus 404
if ($c.Status -eq 404) {
    if ($PSCmdlet.ShouldProcess($CatalogName, 'Create catalog')) {
        Invoke-Dbx POST "$H/api/2.1/unity-catalog/catalogs" @{
            name = $CatalogName; storage_root = $CatalogStorageRoot
            comment = 'Project areas for Databricks cross-charging; one schema per project area.'
        } | Out-Null
        Add-Result created "Catalog $CatalogName (managed location $CatalogStorageRoot)"
    }
} else { Add-Result unchanged "Catalog $CatalogName" }

function Grant-Uc([string]$SecurableType, [string]$FullName, [string]$Principal, [string[]]$Privileges) {
    if (-not $PSCmdlet.ShouldProcess("$SecurableType $FullName", "Grant $($Privileges -join ',') to $Principal")) { return }
    Invoke-Dbx PATCH "$H/api/2.1/unity-catalog/permissions/$SecurableType/$FullName" @{
        changes = @(@{ principal = $Principal; add = $Privileges })
    } | Out-Null
    Add-Result updated "Grant $($Privileges -join ', ') on $SecurableType $FullName to $Principal"
}

function Set-UcTag([string]$EntityType, [string]$FullName, [string]$Key, [string]$Value) {
    $r = Invoke-Dbx GET "$H/api/2.1/unity-catalog/entity-tag-assignments/$EntityType/$FullName/tags/$Key" -AllowStatus 404
    if ($r.Status -ne 404 -and $r.Body.tag_value -eq $Value) { Add-Result unchanged "Tag $Key=$Value on $EntityType $FullName"; return }
    if (-not $PSCmdlet.ShouldProcess("$EntityType $FullName", "Tag $Key=$Value")) { return }
    $body = @{ entity_type = $EntityType; entity_name = $FullName; tag_key = $Key; tag_value = $Value }
    if ($r.Status -eq 404) {
        Invoke-Dbx POST "$H/api/2.1/unity-catalog/entity-tag-assignments" $body | Out-Null
        Add-Result created "Tag $Key=$Value on $EntityType $FullName"
    } else {
        Invoke-Dbx PATCH "$H/api/2.1/unity-catalog/entity-tag-assignments/$EntityType/$FullName/tags/$($Key)?update_mask=tag_value" $body | Out-Null
        Add-Result updated "Tag $Key=$Value on $EntityType $FullName"
    }
}

$ContributorSchemaPrivs = 'USE_SCHEMA', 'SELECT', 'MODIFY', 'EXECUTE', 'READ_VOLUME', 'WRITE_VOLUME',
                          'CREATE_TABLE', 'CREATE_VOLUME', 'CREATE_FUNCTION', 'CREATE_MATERIALIZED_VIEW', 'CREATE_MODEL'
$ReaderSchemaPrivs      = 'USE_SCHEMA', 'SELECT', 'EXECUTE', 'READ_VOLUME'

# ---------- 4. Schemas ----------
foreach ($pa in $ProjectAreas) {
    $full = "$CatalogName.$pa"
    Write-Step "Schema '$full'"
    $s = Invoke-Dbx GET "$H/api/2.1/unity-catalog/schemas/$full" -AllowStatus 404
    if ($s.Status -eq 404) {
        if ($PSCmdlet.ShouldProcess($full, 'Create schema')) {
            Invoke-Dbx POST "$H/api/2.1/unity-catalog/schemas" @{ name = $pa; catalog_name = $CatalogName; comment = "Project area $pa" } | Out-Null
            Add-Result created "Schema $full"
        }
    } else { Add-Result unchanged "Schema $full" }

    Set-UcTag 'schemas' $full $TagKey $pa

    $con = $groups["$pa/contributor"].name; $rdr = $groups["$pa/reader"].name
    Grant-Uc 'catalog' $CatalogName $con @('USE_CATALOG')
    Grant-Uc 'catalog' $CatalogName $rdr @('USE_CATALOG')
    Grant-Uc 'schema'  $full $con $ContributorSchemaPrivs
    Grant-Uc 'schema'  $full $rdr $ReaderSchemaPrivs
}

# ---------- 5. Workspace folders ----------
function Confirm-Folder([string]$Path) {
    $st = Invoke-Dbx GET "$H/api/2.0/workspace/get-status?path=$([uri]::EscapeDataString($Path))" -AllowStatus 404
    if ($st.Status -eq 404) {
        if (-not $PSCmdlet.ShouldProcess($Path, 'Create folder')) { return $null }
        Invoke-Dbx POST "$H/api/2.0/workspace/mkdirs" @{ path = $Path } | Out-Null
        $st = Invoke-Dbx GET "$H/api/2.0/workspace/get-status?path=$([uri]::EscapeDataString($Path))"
        Add-Result created "Folder /Workspace$Path ($($st.Body.object_id))"
    } else { Add-Result unchanged "Folder /Workspace$Path ($($st.Body.object_id))" }
    return $st.Body.object_id
}

Write-Step "Workspace folders under $FolderRoot"
Confirm-Folder $FolderRoot | Out-Null
foreach ($pa in $ProjectAreas) {
    $fid = Confirm-Folder "$FolderRoot/$pa"
    if ($fid -and $PSCmdlet.ShouldProcess("$FolderRoot/$pa", 'Set folder permissions')) {
        # PUT replaces the folder's direct grants, so the result is exactly these two (admins keep inherited CAN_MANAGE).
        Invoke-Dbx PUT "$H/api/2.0/permissions/directories/$fid" @{ access_control_list = @(
            @{ group_name = $groups["$pa/contributor"].name; permission_level = $ContributorFolderPermission },
            @{ group_name = $groups["$pa/reader"].name;      permission_level = 'CAN_READ' }
        ) } | Out-Null
        Add-Result updated "Folder $FolderRoot/${pa}: $($groups["$pa/contributor"].name)=$ContributorFolderPermission, $($groups["$pa/reader"].name)=CAN_READ"
    }
}

# ---------- 6. Serverless usage policies (account-level budget policies) ----------
function Get-AllBudgetPolicies {
    $all = @(); $tok = $null
    do {
        $u = "$A/2.1/accounts/$AccountId/budget-policies?page_size=100" + ($(if ($tok) { "&page_token=$tok" } else { '' }))
        $r = (Invoke-Dbx GET $u).Body
        if ($r.PSObject.Properties['policies']) { $all += $r.policies }
        $tok = $r.PSObject.Properties['next_page_token'] ? $r.next_page_token : $null
    } while ($tok)
    return $all
}

Write-Step 'Serverless usage policies'
$existingBp = Get-AllBudgetPolicies
$policyIds = [ordered]@{}
foreach ($pa in $ProjectAreas) {
    $pname = "pa-$pa"
    $tags = @(@{ key = $TagKey; value = $pa })
    $bp = $existingBp | Where-Object policy_name -eq $pname | Select-Object -First 1
    if (-not $bp) {
        if (-not $PSCmdlet.ShouldProcess($pname, 'Create serverless usage policy')) { continue }
        $r = Invoke-Dbx POST "$A/2.1/accounts/$AccountId/budget-policies" @{ policy = @{ policy_name = $pname; custom_tags = $tags } } -AllowStatus 403
        if ($r.Status -eq 403) {
            # Seen on accounts without the serverless usage policy entitlement, even for account admins.
            Write-Warning "Serverless usage policy $pname NOT created: $($r.Body.message). Create it in Account console > Settings > Serverless usage policies, then re-run."
            $script:Summary.skipped += "Serverless usage policy $pname (403: $($r.Body.message))"
            continue
        }
        $bp = $r.Body
        Add-Result created "Serverless usage policy $pname ($($bp.policy_id)) tag $TagKey=$pa"
    } else {
        $cur = @($bp.PSObject.Properties['custom_tags'] ? $bp.custom_tags : @()) | Where-Object key -eq $TagKey
        if (-not $cur -or $cur.value -ne $pa) {
            if ($PSCmdlet.ShouldProcess($pname, 'Fix policy tag')) {
                # PATCH replaces the whole policy: keep its workspace binding (default to this workspace) and any other tags.
                $bind = @($bp.PSObject.Properties['binding_workspace_ids'] ? $bp.binding_workspace_ids : @())
                if ($bind.Count -eq 0) { $bind = @([long]$WorkspaceId) }
                $otherTags = @(@($bp.PSObject.Properties['custom_tags'] ? $bp.custom_tags : @()) | Where-Object key -ne $TagKey |
                               ForEach-Object { @{ key = $_.key; value = $_.value } })
                Invoke-Dbx PATCH "$A/2.1/accounts/$AccountId/budget-policies/$($bp.policy_id)" @{
                    policy_id = $bp.policy_id; policy_name = $pname; custom_tags = @($otherTags + $tags); binding_workspace_ids = $bind
                } | Out-Null
                Add-Result updated "Serverless usage policy $pname tag $TagKey=$pa"
            }
        } else { Add-Result unchanged "Serverless usage policy $pname ($($bp.policy_id)) tag $TagKey=$pa" }
    }
    $policyIds["serverless/$pa"] = $bp.policy_id

    # Grant the User role to both groups; keep any other rules (e.g. managers) intact.
    $rsName = "accounts/$AccountId/budgetPolicies/$($bp.policy_id)/ruleSets/default"
    $rs = (Invoke-Dbx GET "$A/2.0/preview/accounts/$AccountId/access-control/rule-sets?name=$([uri]::EscapeDataString($rsName))&etag=").Body
    $principals = @("groups/$($groups["$pa/contributor"].name)", "groups/$($groups["$pa/reader"].name)")
    $rules = @(@($rs.PSObject.Properties['grant_rules'] ? $rs.grant_rules : @()) | Where-Object role -ne 'roles/budgetPolicy.user')
    $userRule = @($rs.PSObject.Properties['grant_rules'] ? $rs.grant_rules : @()) | Where-Object role -eq 'roles/budgetPolicy.user'
    $have = @(@($userRule | ForEach-Object { $_.principals }) | Sort-Object)
    $want = @(@($have) + $principals | Select-Object -Unique | Sort-Object)
    if ($have.Count -gt 0 -and @(Compare-Object $have $want).Count -eq 0) {
        Add-Result unchanged "Policy $pname User role: $($principals -join ', ')"
    } elseif ($PSCmdlet.ShouldProcess($pname, 'Grant User role')) {
        $rules += @{ role = 'roles/budgetPolicy.user'; principals = $want }
        Invoke-Dbx PUT "$A/2.0/preview/accounts/$AccountId/access-control/rule-sets" @{
            name = $rsName; rule_set = @{ name = $rsName; grant_rules = $rules; etag = $rs.etag }
        } | Out-Null
        Add-Result updated "Policy $pname User role: $($want -join ', ')"
    }
}

# ---------- 7. Compute policies (classic all-purpose + jobs), Variant B fixed tag ----------
$common = [ordered]@{
    'spark_version'                  = @{ type = 'unlimited'; defaultValue = 'auto:latest-lts' }
    'instance_pool_id'               = @{ type = 'forbidden'; hidden = $true }
    'driver_instance_pool_id'        = @{ type = 'forbidden'; hidden = $true }
    'azure_attributes.availability'  = @{ type = 'allowlist'; values = @('SPOT_WITH_FALLBACK_AZURE', 'ON_DEMAND_AZURE'); defaultValue = 'SPOT_WITH_FALLBACK_AZURE' }
}
function New-PolicyDefinition([string]$Pa, [string]$Kind) {
    $d = [ordered]@{} ; $common.GetEnumerator() | ForEach-Object { $d[$_.Key] = $_.Value }
    $d["custom_tags.$TagKey"] = @{ type = 'fixed'; value = $Pa; hidden = $false }
    if ($Kind -eq 'all-purpose') {
        $d['cluster_type']             = @{ type = 'fixed'; value = 'all-purpose'; hidden = $true }
        $d['data_security_mode']       = @{ type = 'allowlist'; values = @('USER_ISOLATION', 'SINGLE_USER'); defaultValue = 'USER_ISOLATION' }
        $d['autotermination_minutes']  = @{ type = 'range'; minValue = 10; maxValue = 60; defaultValue = 30 }
        # isOptional: a defaultValue alone makes autoscale mandatory and blocks single-node and fixed-size compute.
        $d['autoscale.min_workers']    = @{ type = 'range'; maxValue = 2; defaultValue = 1; isOptional = $true }
        $d['autoscale.max_workers']    = @{ type = 'range'; maxValue = 8; defaultValue = 4; isOptional = $true }
        $d['num_workers']              = @{ type = 'range'; maxValue = 8 }
        $d['dbus_per_hour']            = @{ type = 'range'; maxValue = 20 }
    } else {
        $d['cluster_type']             = @{ type = 'fixed'; value = 'job'; hidden = $true }
        $d['data_security_mode']       = @{ type = 'allowlist'; values = @('SINGLE_USER', 'USER_ISOLATION'); defaultValue = 'SINGLE_USER' }
        $d['autoscale.min_workers']    = @{ type = 'range'; maxValue = 4; defaultValue = 1; isOptional = $true }
        $d['autoscale.max_workers']    = @{ type = 'range'; maxValue = 16; defaultValue = 4; isOptional = $true }
        $d['num_workers']              = @{ type = 'range'; maxValue = 16 }
        $d['dbus_per_hour']            = @{ type = 'range'; maxValue = 40 }
    }
    return ($d | ConvertTo-Json -Depth 10 -Compress)
}

Write-Step 'Compute policies'
$existingCp = @((Invoke-Dbx GET "$H/api/2.0/policies/clusters/list").Body.policies)
foreach ($pa in $ProjectAreas) {
    foreach ($kind in 'all-purpose', 'jobs') {
        $pname = "pa-$pa-$kind"
        $def = New-PolicyDefinition $pa $kind
        $maxPerUser = if ($kind -eq 'all-purpose') { 2 } else { $null }
        $cp = $existingCp | Where-Object name -eq $pname | Select-Object -First 1
        $body = @{ name = $pname; definition = $def; description = "Project area $pa - $kind compute, tag $TagKey=$pa fixed" }
        if ($maxPerUser) { $body.max_clusters_per_user = $maxPerUser }
        if (-not $cp) {
            if (-not $PSCmdlet.ShouldProcess($pname, 'Create compute policy')) { continue }
            $cpId = (Invoke-Dbx POST "$H/api/2.0/policies/clusters/create" $body).Body.policy_id
            Add-Result created "Compute policy $pname ($cpId)"
        } else {
            $cpId = $cp.policy_id
            if ($PSCmdlet.ShouldProcess($pname, 'Update compute policy')) {
                $body.policy_id = $cpId
                Invoke-Dbx POST "$H/api/2.0/policies/clusters/edit" $body | Out-Null
                Add-Result updated "Compute policy $pname ($cpId) definition re-applied"
            }
        }
        $policyIds["$kind/$pa"] = $cpId
        # PUT replaces direct grants: admin-only leaves just the inherited admins CAN_USE.
        $acl = if ($AdminOnlyCompute) { @() } else { @(@{ group_name = $groups["$pa/contributor"].name; permission_level = 'CAN_USE' }) }
        if ($PSCmdlet.ShouldProcess($pname, 'Set CAN_USE')) {
            Invoke-Dbx PUT "$H/api/2.0/permissions/cluster-policies/$cpId" @{ access_control_list = $acl } | Out-Null
            Add-Result updated ("Compute policy $pname CAN_USE -> " + $(if ($AdminOnlyCompute) { 'admins only' } else { $groups["$pa/contributor"].name }))
        }
    }
}

# ---------- 8. Admin-only compute: Personal Compute + one admin-created shared cluster per area ----------
if ($AdminOnlyCompute) {
    Write-Step 'Personal Compute (account setting)'
    $pcUri = "$A/2.0/accounts/$AccountId/settings/types/dcp_acct_enable/names/default"
    $pc = (Invoke-Dbx GET $pcUri).Body
    if ($pc.personal_compute.value -eq 'DELEGATE') { Add-Result unchanged 'Personal Compute = DELEGATE (workspace ACL decides)' }
    elseif ($PSCmdlet.ShouldProcess('Personal Compute', 'Set to DELEGATE')) {
        Invoke-Dbx PATCH $pcUri @{ allow_missing = $true; field_mask = 'personal_compute.value'
            setting = @{ etag = $pc.etag; setting_name = 'default'; personal_compute = @{ value = 'DELEGATE' } } } | Out-Null
        Add-Result updated 'Personal Compute ON -> DELEGATE (only principals granted the policy can use it)'
    }
    # Personal Compute policy itself: admins only (PUT with no direct grants).
    $pcPolicy = $existingCp | Where-Object name -eq 'Personal Compute' | Select-Object -First 1
    if ($pcPolicy -and $PSCmdlet.ShouldProcess('Personal Compute policy', 'Admins only')) {
        Invoke-Dbx PUT "$H/api/2.0/permissions/cluster-policies/$($pcPolicy.policy_id)" @{ access_control_list = @() } | Out-Null
        Add-Result updated 'Personal Compute policy CAN_USE -> admins only'
    }

    Write-Step 'Shared interactive cluster per project area (created by admin)'
    $sv = ((Invoke-Dbx GET "$H/api/2.0/clusters/spark-versions").Body.versions |
           Where-Object { $_.name -match 'LTS' -and $_.name -notmatch 'ML|GPU|Photon|Beta' -and $_.key -match '^\d+\.\d+\.x-scala' } |
           Sort-Object { [version]($_.key -replace '^(\d+\.\d+)\..*', '$1') } -Descending | Select-Object -First 1).key
    $existingClusters = @((Invoke-Dbx GET "$H/api/2.0/clusters/list").Body.PSObject.Properties['clusters'] ? (Invoke-Dbx GET "$H/api/2.0/clusters/list").Body.clusters : @())
    foreach ($pa in $ProjectAreas) {
        $cname = "$pa-interactive"
        $cl = $existingClusters | Where-Object cluster_name -eq $cname | Select-Object -First 1
        if ($cl) { $cid = $cl.cluster_id; Add-Result unchanged "Cluster $cname ($cid)" }
        elseif ($PSCmdlet.ShouldProcess($cname, 'Create cluster')) {
            $cid = (Invoke-Dbx POST "$H/api/2.0/clusters/create" @{
                cluster_name = $cname; policy_id = $policyIds["all-purpose/$pa"]; apply_policy_default_values = $true
                spark_version = $sv; node_type_id = $ClusterNodeType; num_workers = 0
                data_security_mode = 'USER_ISOLATION'; autotermination_minutes = 30
                spark_conf  = @{ 'spark.databricks.cluster.profile' = 'singleNode'; 'spark.master' = 'local[*]' }
                custom_tags = @{ ResourceClass = 'SingleNode' }
                azure_attributes = @{ availability = 'ON_DEMAND_AZURE' }
            }).Body.cluster_id
            # Creating starts the cluster; stop it so nothing runs until a user needs it.
            Invoke-Dbx POST "$H/api/2.0/clusters/delete" @{ cluster_id = $cid } | Out-Null
            Add-Result created "Cluster $cname ($cid, $sv, $ClusterNodeType single node, tag $TagKey=$pa) - terminated until first use"
        }
        if ($cid) {
            $policyIds["cluster/$pa"] = $cid
            if ($PSCmdlet.ShouldProcess($cname, "Grant $ClusterPermission")) {
                Invoke-Dbx PUT "$H/api/2.0/permissions/clusters/$cid" @{ access_control_list = @(
                    @{ group_name = $groups["$pa/contributor"].name; permission_level = $ClusterPermission },
                    @{ group_name = $groups["$pa/reader"].name;      permission_level = $ClusterPermission }
                ) } | Out-Null
                Add-Result updated "Cluster $cname $ClusterPermission -> $($groups["$pa/contributor"].name), $($groups["$pa/reader"].name)"
            }
        }
    }
}

# ---------- summary ----------
$out = [ordered]@{
    runAt = (Get-Date).ToString('o'); workspace = $H; workspaceId = $WorkspaceId; accountId = $AccountId
    catalog = $CatalogName; projectAreas = $ProjectAreas; groups = $groups; users = $userIds; policies = $policyIds
    actions = $script:Summary
}
if (-not $WhatIfPreference) { $out | ConvertTo-Json -Depth 10 | Set-Content -Path $SummaryPath -Encoding utf8 }
Write-Step "Done. created=$($script:Summary.created.Count) updated=$($script:Summary.updated.Count) unchanged=$($script:Summary.unchanged.Count) skipped=$($script:Summary.skipped.Count)"
$script:Summary.skipped | ForEach-Object { Write-Warning "Skipped: $_" }
if (-not $WhatIfPreference) { Write-Host "    Summary written to $SummaryPath" }
