<#
.SYNOPSIS
    Deletes empty Azure resource groups.
.EXAMPLE
    ./Remove-EmptyResourceGroups.ps1                       # dry run (lists only)
    ./Remove-EmptyResourceGroups.ps1 -Force                # delete in current subscription
    ./Remove-EmptyResourceGroups.ps1 -SubscriptionId <id> -Force
    ./Remove-EmptyResourceGroups.ps1 -AllSubscriptions -Force
#>
[CmdletBinding()]
param(
    [string]   $SubscriptionId,
    [switch]   $AllSubscriptions,
    [switch]   $Force,
    [string[]] $Exclude = @('NetworkWatcherRG', 'cloud-shell-storage-*', 'DefaultResourceGroup-*', 'MC_*', 'databricks-rg-*')
)

if (-not (Get-AzContext)) { Connect-AzAccount | Out-Null }

$subs = if ($AllSubscriptions) {
    Get-AzSubscription | Where-Object State -eq 'Enabled'
} elseif ($SubscriptionId) {
    Get-AzSubscription -SubscriptionId $SubscriptionId
} else {
    (Get-AzContext).Subscription
}

$results = foreach ($sub in $subs) {
    Set-AzContext -SubscriptionId $sub.Id | Out-Null
    Write-Host "`nSubscription: $($sub.Name) ($($sub.Id))" -ForegroundColor Cyan

    foreach ($rg in Get-AzResourceGroup) {
        $name = $rg.ResourceGroupName

        if ($Exclude | Where-Object { $name -like $_ }) {
            Write-Verbose "Skipping excluded RG: $name"
            continue
        }

        $resources = Get-AzResource -ResourceGroupName $name -ErrorAction SilentlyContinue
        if ($resources) { continue }

        $locks = Get-AzResourceLock -ResourceGroupName $name -AtScope -ErrorAction SilentlyContinue
        if ($locks) {
            Write-Warning "$name is empty but has a lock ($($locks.Name -join ', ')); skipping."
            $status = 'Locked'
        }
        elseif ($Force) {
            Write-Host "Deleting $name ..." -ForegroundColor Yellow
            try {
                Remove-AzResourceGroup -Name $name -Force -ErrorAction Stop | Out-Null
                $status = 'Deleted'
            } catch {
                Write-Warning "Failed to delete ${name}: $($_.Exception.Message)"
                $status = 'Failed'
            }
        }
        else {
            Write-Host "[Dry run] Would delete: $name" -ForegroundColor Green
            $status = 'WouldDelete'
        }

        [pscustomobject]@{
            Subscription  = $sub.Name
            ResourceGroup = $name
            Location      = $rg.Location
            Status        = $status
        }
    }
}

$results | Format-Table -AutoSize
if (-not $Force -and $results) {
    Write-Host "`nDry run only. Re-run with -Force to delete." -ForegroundColor Cyan
}
