# Databricks notebook source
# MAGIC %md
# MAGIC # Job-to-area reconciliation (PoC design, Appendix A3)
# MAGIC
# MAGIC For every job in the workspace:
# MAGIC 1. Derive the project area from its task notebooks' folder: `/ProjectAreas/<area>/...`
# MAGIC 2. **Serverless jobs**: if the job's serverless usage policy is not the area's policy, set it (mode `apply`) - the folder wins.
# MAGIC    The job tag `projectarea=<area>` is set as well. Billing is correct from the next run on; past runs stay as they were.
# MAGIC 3. **Classic job clusters**: report a compute policy that does not match the area (never changed automatically).
# MAGIC 4. Grant the area's groups access to the job: contributor = Can Manage Run, reader = Can View.
# MAGIC 5. Write the current state to `job_pa_map` and every change to `job_pa_changes`.
# MAGIC
# MAGIC Run as a workspace admin (needs Can Manage on all jobs) who holds the User or Manager role on every area's usage policy.

# COMMAND ----------

dbutils.widgets.dropdown("mode", "apply", ["apply", "report"], "Mode")
dbutils.widgets.dropdown("grant_group_access", "yes", ["yes", "no"], "Grant area groups access to jobs")
dbutils.widgets.text("log_schema", "projectareas.finops", "Schema for job_pa_map / job_pa_changes")

MODE = dbutils.widgets.get("mode")
GRANT = dbutils.widgets.get("grant_group_access") == "yes"
LOG_SCHEMA = dbutils.widgets.get("log_schema")

FOLDER_ROOT = "/ProjectAreas"
# Every area setting comes from dim_project_area, so a new area is one row.
_dim = spark.table(f"{LOG_SCHEMA}.dim_project_area").collect()
USAGE_POLICY = {r["pa_code"]: r["serverless_policy_id"] for r in _dim if r["serverless_policy_id"]}
SCHEMA_AREA = {r["schema"]: r["pa_code"] for r in _dim if r["schema"]}
WAREHOUSE_AREA = {r["sql_warehouse_id"]: r["pa_code"] for r in _dim if r["sql_warehouse_id"] and r["pa_code"] != "platform"}
TAG_KEY = "projectarea"
QUERY_LOOKBACK_HOURS = 48

# COMMAND ----------

import re
from datetime import datetime, timezone
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()
api = w.api_client
NOW = datetime.now(timezone.utc)
area_re = re.compile(rf"^(?:/Workspace)?{re.escape(FOLDER_ROOT)}/([^/]+)/")

# Compute policy names -> ids, to check classic job clusters against pa-<area>-jobs
compute_policies = {p["name"]: p["policy_id"] for p in api.do("GET", "/api/2.0/policies/clusters/list").get("policies", [])}
policy_name_by_id = {v: f"pa-{k}" for k, v in USAGE_POLICY.items()}


def list_jobs():
    page = None
    while True:
        q = {"limit": 100, "expand_tasks": "true"}
        if page:
            q["page_token"] = page
        r = api.do("GET", "/api/2.2/jobs/list", query=q)
        for j in r.get("jobs", []):
            yield j["job_id"]
        page = r.get("next_page_token")
        if not page:
            return


def flatten(tasks):
    for t in tasks or []:
        yield t
        inner = (t.get("for_each_task") or {}).get("task")
        if inner:
            yield from flatten([inner])


def reconcile(job_id):
    job = api.do("GET", "/api/2.2/jobs/get", query={"job_id": job_id})
    s = job["settings"]
    tasks = list(flatten(s.get("tasks")))
    row = {"job_id": str(job_id), "job_name": s.get("name"), "creator": job.get("creator_user_name"),
           "pa_code": None, "status": None, "action": None, "is_serverless": None,
           "current_policy": s.get("budget_policy_id"), "effective_policy": job.get("effective_budget_policy_id"),
           "expected_policy": None, "task_notebook_paths": None, "last_checked": NOW}

    nb_tasks = [t for t in tasks if "notebook_task" in t]
    if not nb_tasks:
        row.update(status="no_notebook_task")
        return row, []
    paths = [t["notebook_task"]["notebook_path"] for t in nb_tasks]
    row["task_notebook_paths"] = ", ".join(paths)
    from_git = any((t["notebook_task"].get("source") or "WORKSPACE") == "GIT" for t in nb_tasks)
    areas = {m.group(1) for p in paths if (m := area_re.match(p))}
    if from_git or not areas:
        row.update(status="no_folder_match")
        return row, []
    if len(areas) > 1:
        row.update(status="ambiguous", pa_code=",".join(sorted(areas)))
        return row, []
    pa = areas.pop()
    row["pa_code"] = pa
    if pa not in USAGE_POLICY:
        row.update(status="unknown_area")
        return row, []
    expected = USAGE_POLICY[pa]
    row["expected_policy"] = expected

    changes = []
    def change(what, old, new):
        changes.append({"changed_at": NOW, "job_id": str(job_id), "job_name": s.get("name"), "creator": job.get("creator_user_name"),
                        "pa_code": pa, "change": what, "old_value": old, "new_value": new, "mode": MODE})

    # Classic compute: an existing all-purpose cluster or a job cluster
    on_all_purpose = any(t.get("existing_cluster_id") for t in tasks)
    job_clusters = s.get("job_clusters") or []
    classic = on_all_purpose or bool(job_clusters) or any(t.get("new_cluster") for t in tasks)
    row["is_serverless"] = not classic

    if classic:
        if on_all_purpose:
            row.update(status="on_all_purpose_cluster", action="move to serverless or jobs compute")
        else:
            want = compute_policies.get(f"pa-{pa}-jobs")
            used = {(jc.get("new_cluster") or {}).get("policy_id") for jc in job_clusters} | \
                   {(t.get("new_cluster") or {}).get("policy_id") for t in tasks if t.get("new_cluster")}
            row.update(status="classic_ok" if used == {want} else "classic_mismatch",
                       action=None if used == {want} else f"owner: use compute policy pa-{pa}-jobs")
    else:
        current, effective = s.get("budget_policy_id"), job.get("effective_budget_policy_id")
        tags = dict(s.get("tags") or {})
        if current == expected and tags.get(TAG_KEY) == pa:
            row.update(status="ok")
        else:
            was = "mismatch" if (current or effective) not in (None, expected) else "to_tag"
            new_settings = {"budget_policy_id": expected, "tags": {**tags, TAG_KEY: pa}}
            if MODE == "apply":
                api.do("POST", "/api/2.2/jobs/update", body={"job_id": job_id, "new_settings": new_settings})
                row.update(status=f"corrected_{was}", action="policy and tag set", current_policy=expected)
            else:
                row.update(status=was, action="would set policy and tag")
            if current != expected:
                change("usage_policy", policy_name_by_id.get(current or effective, current or effective), f"pa-{pa}")
            if tags.get(TAG_KEY) != pa:
                change("tag", tags.get(TAG_KEY), pa)

    if GRANT:
        acl = api.do("GET", f"/api/2.0/permissions/jobs/{job_id}").get("access_control_list", [])
        have = {(a.get("group_name"), p["permission_level"]) for a in acl for p in a.get("all_permissions", [])}
        want = [(f"pa-{pa}-contributor", "CAN_MANAGE_RUN"), (f"pa-{pa}-reader", "CAN_VIEW")]
        missing = [x for x in want if x not in have]
        if missing:
            if MODE == "apply":
                api.do("PATCH", f"/api/2.0/permissions/jobs/{job_id}",
                       body={"access_control_list": [{"group_name": g, "permission_level": l} for g, l in missing]})
            for g, l in missing:
                change("permission", None, f"{g}={l}")
    return row, changes

# COMMAND ----------

rows, changes = [], []
for jid in list_jobs():
    try:
        r, c = reconcile(jid)
    except Exception as e:  # one bad job must not stop the run
        r, c = {"job_id": str(jid), "status": "error", "action": str(e)[:500], "last_checked": NOW}, []
    rows.append(r)
    changes += c

print(f"mode={MODE}: {len(rows)} jobs checked, {len(changes)} changes")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pipelines: same rule as jobs (folder first, then target schema)

# COMMAND ----------

def reconcile_pipeline(pid):
    p = api.do("GET", f"/api/2.0/pipelines/{pid}")
    spec = p.get("spec") or {}
    row = {"job_id": f"pipeline:{pid}", "job_name": f"pipeline: {p.get('name')}", "creator": p.get("creator_user_name"),
           "current_policy": spec.get("budget_policy_id"), "effective_policy": p.get("effective_budget_policy_id"),
           "is_serverless": bool(spec.get("serverless")), "last_checked": NOW}
    paths = [v["path"] for lib in spec.get("libraries", []) for v in lib.values() if isinstance(v, dict) and v.get("path")]
    row["task_notebook_paths"] = ", ".join(paths)
    areas = {m.group(1) for x in paths if (m := area_re.match(x))}
    if not areas and spec.get("catalog") == "projectareas":
        area = SCHEMA_AREA.get(spec.get("schema") or spec.get("target"))
        areas = {area} if area else set()
    if not areas:
        row.update(status="no_folder_match")
        return row, []
    if len(areas) > 1:
        row.update(status="ambiguous", pa_code=",".join(sorted(areas)))
        return row, []
    pa = areas.pop()
    expected = USAGE_POLICY.get(pa)
    row.update(pa_code=pa, expected_policy=expected)
    if not expected:
        row.update(status="unknown_area")
        return row, []
    if not spec.get("serverless"):
        row.update(status="classic_pipeline", action="usage policies apply to serverless pipelines only")
        return row, []
    current = spec.get("budget_policy_id")
    if current == expected:
        row.update(status="ok")
        return row, []
    if MODE == "apply":
        api.do("PUT", f"/api/2.0/pipelines/{pid}", body={**spec, "id": pid, "budget_policy_id": expected})
        row.update(status="corrected_mismatch" if current else "corrected_to_tag", action="policy set", current_policy=expected)
    else:
        row.update(status="mismatch" if current else "to_tag", action="would set policy")
    return row, [{"changed_at": NOW, "job_id": row["job_id"], "job_name": row["job_name"], "creator": row["creator"], "pa_code": pa,
                  "change": "usage_policy", "old_value": policy_name_by_id.get(current, current), "new_value": f"pa-{pa}", "mode": MODE}]

page = None
while True:
    r = api.do("GET", "/api/2.0/pipelines", query={"max_results": 100, **({"page_token": page} if page else {})})
    for st in r.get("statuses", []):
        try:
            row, c = reconcile_pipeline(st["pipeline_id"])
        except Exception as e:
            row, c = {"job_id": f"pipeline:{st['pipeline_id']}", "status": "error", "action": str(e)[:500], "last_checked": NOW}, []
        rows.append(row)
        changes += c
    page = r.get("next_page_token")
    if not page:
        break

# COMMAND ----------

# MAGIC %md
# MAGIC ## Who belongs to which area (multi-area users, primary area)

# COMMAND ----------

group_re = re.compile(r"^pa-(.+)-(?:contributor|reader)$")
members, start = [], 1
while True:
    r = api.do("GET", "/api/2.0/preview/scim/v2/Users", query={"attributes": "userName,groups", "startIndex": start, "count": 100})
    res = r.get("Resources", [])
    for u in res:
        for g in u.get("groups", []):
            m = group_re.match(g.get("display") or "")
            if m and m.group(1) in USAGE_POLICY:
                members.append((u["userName"], m.group(1)))
    start += len(res)
    if not res or start > int(r.get("totalResults", 0)):
        break

spark.createDataFrame(sorted(set(members)), "user_email string, pa_code string").write.mode("overwrite").saveAsTable(f"{LOG_SCHEMA}.user_area_membership")
# Single-area users have one possible primary area. Multi-area users are nominated by area owners, never guessed.
spark.sql(f"""MERGE INTO {LOG_SCHEMA}.user_primary_pa t
USING (SELECT user_email, MIN(pa_code) AS pa_code FROM {LOG_SCHEMA}.user_area_membership GROUP BY user_email HAVING COUNT(DISTINCT pa_code) = 1) s
ON t.user_email = s.user_email AND t.valid_to IS NULL
WHEN NOT MATCHED THEN INSERT (user_email, pa_code, valid_from, valid_to) VALUES (s.user_email, s.pa_code, current_date(), NULL)""")

# COMMAND ----------

# MAGIC %md
# MAGIC ## SQL warehouses: compare each query's data or saved folder with the warehouse's area
# MAGIC Reporting only: the warehouse tag and billing rows cannot change. The cost view splits the affected hours.
# MAGIC Only the derived area is stored, never the query text.

# COMMAND ----------

import time

table_re = re.compile(r"`?projectareas`?\s*\.\s*`?([A-Za-z0-9_-]+)`?", re.I)
saved_query_area = {}

def area_of_saved_query(qid):
    if qid not in saved_query_area:
        try:
            parent = api.do("GET", f"/api/2.0/sql/queries/{qid}").get("parent_path") or ""
            m = area_re.match(parent.rstrip("/") + "/")
            saved_query_area[qid] = m.group(1) if m and m.group(1) in USAGE_POLICY else None
        except Exception:
            saved_query_area[qid] = None
    return saved_query_area[qid]

now_ms = int(time.time() * 1000)
body = {"max_results": 1000, "include_metrics": True,
        "filter_by": {"warehouse_ids": list(WAREHOUSE_AREA), "statuses": ["FINISHED"],
                      "query_start_time_range": {"start_time_ms": now_ms - QUERY_LOOKBACK_HOURS * 3600000, "end_time_ms": now_ms}}}
query_rows = []
while True:
    r = api.do("GET", "/api/2.0/sql/history/queries", body=body)
    for q in r.get("res", []):
        wh_area = WAREHOUSE_AREA.get(q.get("warehouse_id"))
        qsrc = q.get("query_source") or {}
        path_area = area_of_saved_query(qsrc["sql_query_id"]) if qsrc.get("sql_query_id") else None
        read_areas = {SCHEMA_AREA[s.lower()] for s in table_re.findall(q.get("query_text") or "") if s.lower() in SCHEMA_AREA}
        if path_area:
            signal, area = "saved_folder", path_area
        elif len(read_areas) == 1:
            signal, area = "tables_read", next(iter(read_areas))
        elif len(read_areas) > 1:
            signal, area = "tables_read", None
        else:
            signal, area = "none", None
        status = "ambiguous" if signal == "tables_read" and area is None else "no_signal" if area is None else "ok" if area == wh_area else "mismatch"
        query_rows.append((q["query_id"], q.get("warehouse_id"), wh_area, q.get("user_name"),
                           datetime.fromtimestamp(q["query_start_time_ms"] / 1000, timezone.utc).replace(tzinfo=None),
                           int((q.get("metrics") or {}).get("task_total_time_ms") or 0), area, signal, status, NOW.replace(tzinfo=None)))
    if not r.get("has_next_page"):
        break
    body = {"max_results": 1000, "include_metrics": True, "page_token": r["next_page_token"]}

print(f"{len(query_rows)} warehouse queries checked, {sum(1 for x in query_rows if x[8] == 'mismatch')} mismatches")
if query_rows:
    spark.createDataFrame(query_rows, """query_id string, warehouse_id string, warehouse_area string, user_name string, start_time timestamp,
        task_ms bigint, signal_area string, signal string, status string, last_checked timestamp""").createOrReplaceTempView("new_queries")
    spark.sql(f"""MERGE INTO {LOG_SCHEMA}.query_pa_map t USING new_queries s ON t.query_id = s.query_id
                  WHEN MATCHED THEN UPDATE SET * WHEN NOT MATCHED THEN INSERT *""")

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, BooleanType, TimestampType

map_schema = StructType([StructField(n, t) for n, t in [
    ("job_id", StringType()), ("job_name", StringType()), ("creator", StringType()), ("pa_code", StringType()),
    ("status", StringType()), ("action", StringType()), ("is_serverless", BooleanType()),
    ("current_policy", StringType()), ("effective_policy", StringType()), ("expected_policy", StringType()),
    ("task_notebook_paths", StringType()), ("last_checked", TimestampType())]])
chg_schema = StructType([StructField(n, t) for n, t in [
    ("changed_at", TimestampType()), ("job_id", StringType()), ("job_name", StringType()), ("creator", StringType()),
    ("pa_code", StringType()), ("change", StringType()), ("old_value", StringType()), ("new_value", StringType()),
    ("mode", StringType())]])

spark.sql(f"CREATE SCHEMA IF NOT EXISTS {LOG_SCHEMA} COMMENT 'FinOps reference and log tables for project-area cross-charging'")
map_df = spark.createDataFrame([{k: r.get(k) for k in map_schema.fieldNames()} for r in rows], map_schema)
map_df.write.mode("overwrite").option("overwriteSchema", "true").saveAsTable(f"{LOG_SCHEMA}.job_pa_map")
if changes:
    spark.createDataFrame(changes, chg_schema).write.mode("append").saveAsTable(f"{LOG_SCHEMA}.job_pa_changes")
else:
    spark.sql(f"CREATE TABLE IF NOT EXISTS {LOG_SCHEMA}.job_pa_changes ({', '.join(f'{f.name} {f.dataType.simpleString()}' for f in chg_schema)})")

display(map_df.orderBy("status", "job_name"))

# COMMAND ----------

display(spark.table(f"{LOG_SCHEMA}.job_pa_changes").orderBy("changed_at", ascending=False).limit(100))
